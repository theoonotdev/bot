# 🤖 Vigo Assistant

**WhatsApp Multi-Device Bot** dengan sistem plugin modular.

- **Nama Bot:** Vigo Assistant
- **Owner:** Epan
- **Versi:** 1.8.0
- **Baileys:** npm:@badzz88/baileys

## ⚙️ Instalasi

```bash
npm install
node index.js
```

## 📋 Persyaratan

- Node.js >= 22.0.0

## 🗂️ Struktur Plugin

```
plugins/
├── ai/          → Fitur AI (GPT, Deepseek, Gemini, dll)
├── anime/       → Fitur Anime
├── canvas/      → Fitur Canvas/Fake
├── convert/     → Konversi file
├── download/    → Downloader (YT, TikTok, IG, dll)
├── fun/         → Hiburan
├── game/        → Game (Tebak, RPG, dll)
├── group/       → Manajemen Grup
├── info/        → Informasi
├── owner/       → Fitur Owner
├── search/      → Pencarian
├── sticker/     → Sticker
├── tools/       → Tools
├── user/        → Fitur User (Level, Koin, dll)
└── ...
```

## ⚙️ Konfigurasi

Edit `config.js` untuk mengatur:
- Nomor owner
- Nomor pairing
- API Keys
- Fitur on/off
