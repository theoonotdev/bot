import fs from 'fs'
import path from 'path'
import te from '../../src/lib/vigo-error.js'
const pluginConfig = {
    name: 'ganti-vigo-levelup.jpg',
    alias: ['gantivigolevelup', 'setvigolevelup'],
    category: 'owner',
    description: 'Ganti gambar vigo-levelup.jpg',
    usage: '.ganti-vigo-levelup.jpg (reply/kirim gambar)',
    example: '.ganti-vigo-levelup.jpg',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
    if (!isImage) return m.reply(`🖼️ *ɢᴀɴᴛɪ VIGO-LEVELUP.JPG*\n\n> Kirim/reply gambar untuk mengganti\n> File: assets/images/vigo-levelup.jpg`)
    try {
        let buffer = m.quoted && m.quoted.isMedia ? await m.quoted.download() : await m.download()
        if (!buffer) return m.reply('❌ Gagal mendownload gambar')
        const targetPath = path.join(process.cwd(), 'assets', 'images', 'vigo-levelup.jpg')
        fs.writeFileSync(targetPath, buffer)
        m.reply(`✅ *ʙᴇʀʜᴀsɪʟ*\n\n> Gambar vigo-levelup.jpg telah diganti`)
    } catch (error) {
        await m.reply(te(m.prefix, m.command, m.pushName))
    }
}

export { pluginConfig as config, handler }