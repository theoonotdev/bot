import fs from 'fs'
import path from 'path'
import te from '../../src/lib/vigo-error.js'
const pluginConfig = {
    name: 'ganti-vigo-promote.jpg',
    alias: ['gantivigopromote', 'setvigopromote'],
    category: 'owner',
    description: 'Ganti gambar vigo-promote.jpg',
    usage: '.ganti-vigo-promote.jpg (reply/kirim gambar)',
    example: '.ganti-vigo-promote.jpg',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
    if (!isImage) return m.reply(`🖼️ *ɢᴀɴᴛɪ VIGO-PROMOTE.JPG*\n\n> Kirim/reply gambar untuk mengganti\n> File: assets/images/vigo-promote.jpg`)
    try {
        let buffer = m.quoted && m.quoted.isMedia ? await m.quoted.download() : await m.download()
        if (!buffer) return m.reply('❌ Gagal mendownload gambar')
        const targetPath = path.join(process.cwd(), 'assets', 'images', 'vigo-promote.jpg')
        fs.writeFileSync(targetPath, buffer)
        m.reply(`✅ *ʙᴇʀʜᴀsɪʟ*\n\n> Gambar vigo-promote.jpg telah diganti`)
    } catch (error) {
        await m.reply(te(m.prefix, m.command, m.pushName))
    }
}

export { pluginConfig as config, handler }