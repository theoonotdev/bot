import crypto from "crypto";
import config, { getOwnerName } from "../../config.js";
import { getDatabase } from "../../src/lib/vigo-database.js";
import {
  proto,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
} from "baileys";
const pluginConfig = {
  name: "owner",
  alias: ["creator", "dev", "developer"],
  category: "main",
  description: "Menampilkan kontak owner bot",
  usage: ".owner",
  example: ".owner",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  energi: 0,
  isEnabled: true,
};

async function handler(m, { sock, config: botConfig }) {
  const db = getDatabase();
  const ownerType = db.setting("ownerType") || 1;
  const configOwners = botConfig.owner?.number || [];
  const dbOwners = db.data.owner || [];
  const ownerNumbers = [...new Set([...configOwners, ...dbOwners])];
  const botName = botConfig.bot?.name || "Vigo-Assistant";

  if (ownerType === 2) {
    const carouselCards = [];

    for (const number of ownerNumbers) {
      const cleanNumber = number.replace(/[^0-9]/g, "");
      const jid = cleanNumber + "@s.whatsapp.net";
      const ownerName = getOwnerName(number);

      let cardMedia = null;
      try {
        const ppUrl = await sock.profilePictureUrl(jid, "image");
        cardMedia = await prepareWAMessageMedia(
          { image: { url: ppUrl } },
          { upload: sock.waUploadToServer },
        );
      } catch {}

      carouselCards.push(
        proto.Message.InteractiveMessage.fromObject({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: ownerName,
            hasMediaAttachment: !!cardMedia,
            ...(cardMedia || {}),
          }),
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: `Rules:\n- Jangan spam\n- Jangan VidCall/Call Sembarangan\n- Jangan jadiin bahan bug/banned`,
          }),
          footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: botName,
          }),
          nativeFlowMessage:
            proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "💬 Chat Owner",
                    url: `https://wa.me/${cleanNumber}`,
                  }),
                },
              ],
            }),
        }),
      );
    }

    const msg = await generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              messageSecret: crypto.randomBytes(32),
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `Hallo *${m.pushName}*\n\nKamu ingin mengetahui owner dari bot ini yak?\n\nDi bawah ini adalah owner dari bot kami: ${botName}`,
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: botName,
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: "Owner Info",
                hasMediaAttachment: false,
              }),
              carouselMessage:
                proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                  cards: carouselCards,
                  messageVersion: 1,
                  carouselCardType: 1,
                }),
            }),
          },
        },
      },
      { userJid: m.sender, quoted: m.raw },
    );
    await sock.relayMessage(m.chat, msg.message, {
      messageId: msg.key.id,
    });
  } else if (ownerType === 3) {
    const contacts = [];

    for (const number of ownerNumbers) {
      const cleanNumber = number.replace(/[^0-9]/g, "");

      const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${getOwnerName(number)} (Owner ${botName})\nTEL;type=CELL;type=VOICE;waid=${cleanNumber}:+${cleanNumber}\nEND:VCARD`;

      contacts.push({ vcard });
    }

    await sock.sendMessage(
      m.chat,
      {
        contacts: {
          displayName: `${botName} Owners`,
          contacts,
        },
      },
      { quoted: m.raw },
    );
  } else {
    const ownerText = `👑 *ᴏᴡɴᴇʀ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ*\n\n╭┈┈⬡「 📋 *ᴅᴇᴛᴀɪʟ* 」\n┃ ㊗ ɴᴀᴍᴀ: *${ownerNumbers.map((n) => getOwnerName(n)).join(", ")}*\n┃ ㊗ ʙᴏᴛ: *${botName}*\n┃ ㊗ sᴛᴀᴛᴜs: *🟢 Online*\n╰┈┈⬡\n\n> _Jika ada pertanyaan atau kendala,_\n> _silakan hubungi owner di atas!_\n> _📞 Contact card di bawah._`;

    await m.reply(ownerText);

    for (const number of ownerNumbers) {
      const cleanNumber = number.replace(/[^0-9]/g, "");

      const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${getOwnerName(number)} (Owner ${botName})\nTEL;type=CELL;type=VOICE;waid=${cleanNumber}:+${cleanNumber}\nEND:VCARD`;

      await sock.sendMessage(
        m.chat,
        {
          contacts: {
            displayName: getOwnerName(number),
            contacts: [{ vcard }],
          },
        },
        { quoted: m.raw },
      );
    }
  }
}

export { pluginConfig as config, handler };
