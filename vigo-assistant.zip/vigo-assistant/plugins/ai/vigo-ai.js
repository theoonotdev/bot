import { UnlimitedAI } from "../../src/scraper/unlimitedai.js";
import te from "../../src/lib/vigo-error.js";

const pluginConfig = {
  name: "vigo-ai",
  alias: ["vigoai", "vigo"],
  category: "ai",
  description: "Chat dengan Vigo Assistant — Asisten bot cerdas",
  usage: ".vigo-ai <pertanyaan>",
  example: ".vigo-ai Apa itu Node.js?",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  energi: 2,
  isEnabled: true,
};

async function handler(m, { sock }) {
  const text = m.args.join(" ");
  if (!text) {
    return m.reply(
      `🤖 *Vigo Assistant*\n\n` +
        `> Asisten cerdas siap membantu\n\n` +
        `*PENGGUNAAN:*\n` +
        `> *${m.prefix}vigo-ai <pertanyaan>*\n\n` +
        `*CONTOH:*\n` +
        `> *${m.prefix}vigo-ai Apa itu Node.js?*`
    );
  }

  await m.react("🕕");

  try {
    const result = await UnlimitedAI(text, "vigo-ai");

    if (!result.status) {
      await m.react("☢");
      return m.reply(`❌ *Vigo Assistant Error*\n\n> ${result.error || "Gagal mendapatkan respons"}`);
    }

    await m.react("✅");
    const reply = result.answer;
    await m.reply(reply.length > 4096 ? reply.slice(0, 4096) + "..." : reply);
  } catch (e) {
    console.error(e);
    await m.react("☢");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { pluginConfig as config, handler };
